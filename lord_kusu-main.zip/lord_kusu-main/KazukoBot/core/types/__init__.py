# flake8: noqa

from .InlineQueryResult import (InlineQueryResultAudio,
                                InlineQueryResultCachedDocument)

__help__= f"""

*Kazuko AI Chatbot* 
/addchat : Enables and Disables kazuko AI Chat mode (EXCLUSIVE)
"""

__mod_name__ = "ChatBot"

from KazukoBot import DEV_USERS

SUDOERS = DEV_USERS

# File for All Your Dependency Shit
# You're free to use this for other Definitions
